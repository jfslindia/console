<!-- * Created by PhpStorm.
 * User: targetman
 * Date: 4/5/2017
 * Time: 1:43 PM
 */-->


<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

?>
<!--styles are here-->

<script type="text/javascript">

    $(document).ready(function () {


        $('#loading').hide();

        $("#change_password_button").click(function () {

            var old_password = $("#old_password").val();

            var new_password = $("#new_password").val();

            var re_enter_password = $("#re_enter_password").val();

            //event.preventDefault();

            if (old_password != new_password) {

                if (new_password == re_enter_password) {

                    jQuery.ajax({
                        type: "POST",
                        url: "<?php echo base_url(); ?>" + "admin_controller/change_password",
                        dataType: 'json',
                        data: {
                            old_password: old_password,
                            new_password: new_password
                        },
                        xhr: function () {
                            var xhr = new window.XMLHttpRequest();
                            //Download progress
                            xhr.addEventListener("progress", function (evt) {
                                if (evt.lengthComputable) {
                                    var percentComplete = evt.loaded / evt.total;
                                    //progressElem.value+=Math.round(percentComplete * 100);
                                }
                            }, false);
                            return xhr;
                        },
                        beforeSend: function () {
                            $('#loading').show();
                            $('#change_password_button').hide();

                        },
                        complete: function () {
                            $("#loading").hide();
                            $('#change_password_button').show();

                        },
                        success: function (res) {
                            //console.log(res);
                            if (res.status == 'success') {
                                //console.log('ok');

                                UIkit.notification({
                                    message: 'Password changed',
                                    status: 'success',
                                    pos: 'bottom-center',
                                    timeout: 1000
                                });

                                setTimeout(function () {

                                    window.location = "<?php  echo base_url();?>console/logout";
                                }, 1000);

                            }
                            else if (res.status == 'failed') {

                                UIkit.notification({
                                    message: 'Failed',
                                    status: 'danger',
                                    pos: 'bottom-center',
                                    timeout: 1000
                                });
                            }

                            else if (res.status == 'wrong_password') {

                                UIkit.notification({
                                    message: 'Wrong Password',
                                    status: 'warning',
                                    pos: 'bottom-center',
                                    timeout: 1000
                                });
                            }


                        },
                        error: function (res) {

                            //console.log(res);
                        }

                    });


                } else {

                    UIkit.notification({
                        message: 'Enter the same password',
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                }


            }

            else {

                UIkit.notification({
                    message: 'Password must be different',
                    status: 'warning',
                    pos: 'bottom-center',
                    timeout: 1000
                });
            }

        });

    });


</script>


<div class="uk-width-1-1@s uk-width-4-5@m uk-margin-auto-left content_wrapper">

    <div id="page-1-container">

        <div class="uk-card uk-align-center uk-card-default uk-card-hover uk-card-body">

            <!--uk-width-1-2@l uk-width-1-2@m uk-width-1-2@s-->
            <h3 class="uk-heading-divider uk-text-center">Change Password</h3>

            <div class="uk-grid" id="grid">

                <form class="uk-form-horizontal uk-margin-large uk-align-center">

                    <div class="uk-margin">
                        <label class="uk-form-label" for="form-horizontal-text">Old Password</label>

                        <div class="uk-form-controls">
                            <input type="password" id="old_password" class="uk-input">
                        </div>
                    </div>

                    <div class="uk-margin">
                        <label class="uk-form-label" for="form-horizontal-text">New Password</label>

                        <div class="uk-form-controls">
                            <input type="password" id="new_password" class="uk-input">
                        </div>
                    </div>

                    <div class="uk-margin">
                        <label class="uk-form-label" for="form-horizontal-text">Re-enter Password</label>

                        <div class="uk-form-controls">
                            <input type="password" id="re_enter_password" class="uk-input">
                        </div>
                    </div>


                    <div class="uk-margin">

                        <button id="change_password_button" type="button"
                                class="uk-button uk-button-primary uk-display-block uk-margin-small-top uk-float-right">
                            Change Password
                        </button>
                        <div uk-spinner id="loading" class="uk-flex uk-flex-center"></div>
                    </div>
                    <div class="uk-clearfix"></div>

                    <!-- <progress class="uk-progress" value="0" max="100" id="progressElem"></progress> -->
                    <div id="resfield" style="display: block; width: 100%; margin:auto;"></div>
                </form>

            </div>

        </div>

    </div>


    <div id="res" class="uk-grid uk-align-center uk-width-1-2\@s uk-width-1-3\@m uk-width-1-4\@l" style="display: none">

        <table class="uk-table uk-table-hover" id="result-table">
            <thead>
            <tr>
                <th>#</th>
                <th id="head-1">Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>

            </tr>
            </thead>
            <tbody id="result-table-body">

            <!--content-->

            </tbody>
        </table>
    </div>

</div>




