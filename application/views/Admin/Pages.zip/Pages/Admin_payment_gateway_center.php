<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<script>
    $(document).ready(function () {

        $('#loading').hide();
        $('#user_table_block').hide();
        $('#transaction_info_block').hide();
        $('#transaction_payment_info_block').hide();


        $('#search_text').keydown(function (event) {

            if (event.keyCode == 13) {
                $('#search_button').hide();
                event.preventDefault();
                search();
            }

        });


        $('#search_button').click(function (event) {
            $('#search_button').hide();
            event.preventDefault();
            search();
        });

    });


    function search() {

        var search_text = $('#search_text').val();
        var search_with = $('#search_with').val();

        jQuery.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>" + "Admin_Controller/search_payment",
            dataType: 'json',
            data: {

                search_text: search_text,
                search_with: search_with
            },
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                //Download progress
                xhr.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                        //progressElem.value+=Math.round(percentComplete * 100);
                    }
                }, false);
                return xhr;
            },
            beforeSend: function () {
                $('#loading').show();


            },
            complete: function () {
                $("#loading").hide();
                $('#search_button').show();

            },
            success: function (res) {

                if (res.status == "failed") {
                    // Show Entered Value

                    UIkit.notification({
                        message: 'No such results',
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });
                    $('#user_table_body').html('');
                    $('#transaction_info_table_body').html('');
                    $('#transaction_payment_info_table_body').html('');


                    $('#user_table_block').hide();
                    $('#transaction_info_block').hide();
                    $('#transaction_payment_info_block').hide();

                }
                else if (res.status == "error") {

                    UIkit.notification({
                        message: res.message,
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                    $('#user_table_body').html('');
                    $('#transaction_info_table_body').html('');
                    $('#transaction_payment_info_table_body').html('');


                    $('#user_table_block').hide();
                    $('#transaction_info_block').hide();
                    $('#transaction_payment_info_block').hide();

                }

                else if (res.status == "success") {


                    $('#user_table_body').html('');
                    $('#transaction_info_table_body').html('');
                    $('#transaction_payment_info_table_body').html('');

                    UIkit.notification({
                        message: 'Succesfully retreived results',
                        status: 'success',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                    if (res.result.customer_details) {

                        $('#user_table_body').append('<tr>' +

                            '<td>' + res.result.customer_details['customer_id'] + ' </td>' +
                            '<td>' + res.result.customer_details['name'] + ' </td>' +
                            '<td>' + res.result.customer_details['mobile_number'] + ' </td>' +
                            '<td>' + res.result.customer_details['email'] + ' </td>' +
                            '<td><a onclick=unsettled_orders("' + res.result.customer_details['customer_id'] + '") >Show orders</a></td>' +

                            '</tr>'
                        )


                        $('#user_table_block').show();
                    }

                    if (res.result.transaction_info_details.length > 0) {

                        for (var i = 0; i < res.result.transaction_info_details.length; i++) {

                            if (!res.result.transaction_info_details[i]["DCNo"]) {
                                dcn = 'NA <a onclick=update_dcn("' + jQuery.trim(res.result.transaction_info_details[i]["Id"]) + '") uk-icon="pencil"></a>';
                            } else {
                                dcn = res.result.transaction_info_details[i]["DCNo"];
                            }


                            $('#transaction_info_table_body').append('<tr>' +

                                '<td>' + res.result.transaction_info_details[i]['Id'] + ' </td>' +
                                '<td>' + res.result.transaction_info_details[i]['TransactionDate'] + ' </td>' +
                                '<td>' + res.result.transaction_info_details[i]['TransactionId'] + ' </td>' +
                                '<td>' + res.result.transaction_info_details[i]['PaymentId'] + ' </td>' +
                                '<td>' + res.result.transaction_info_details[i]['EGRNNo'] + ' </td>' +
                                '<td>' + dcn + ' </td>' +
                                '<td>' + res.result.transaction_info_details[i]['TotalPayableAmount'] + ' </td>' +
                                '<td>' + res.result.transaction_info_details[i]['PaymentSource'] + ' </td>' +

                                '</tr>'
                            )
                        }

                        $('#transaction_info_block').append("<p id='add_payment_info_entry_block' class='uk-text-center'><a type='button' class='uk-button uk-button-default' onclick=new_payment_info_entry() uk-icon='plus'>Add a new entry in transaction payment info table</a></p>")
                        $('#transaction_info_block').show();
                    }

                    if (res.result.transaction_payment_info_details.length > 0) {

                        for (var i = 0; i < res.result.transaction_payment_info_details.length; i++) {

                            var settlement_procedure = 'NA';
                            if (res.result.transaction_payment_info_details[i]['settlement_procedure']) {
                                settlement_procedure = res.result.transaction_payment_info_details[i]['settlement_procedure'];
                            }

                            var invoice_no = 'NA';
                            if (res.result.transaction_payment_info_details[i]['InvoiceNo']) {
                                invoice_no = res.result.transaction_payment_info_details[i]['InvoiceNo'];
                            }

                            var settle = '';
                            if (invoice_no == 'NA') {
                                settle = '<a onclick=settle("' + res.result.transaction_payment_info_details[i]['Id'] + '") type="button" class="uk-button">Settle</a>';
                            } else {
                                settle = invoice_no;
                            }

                            $('#transaction_payment_info_table_body').append('<tr>' +

                                '<td>' + res.result.transaction_payment_info_details[i]['Id'] + ' </td>' +
                                '<td>' + res.result.transaction_payment_info_details[i]['CreatedOn'] + ' </td>' +
                                '<td>' + res.result.transaction_payment_info_details[i]['TransactionId'] + ' </td>' +
                                '<td>' + res.result.transaction_payment_info_details[i]['PaymentId'] + ' </td>' +
                                '<td>' + res.result.transaction_payment_info_details[i]['PaymentAmount'] + ' </td>' +
                                '<td>' + res.result.transaction_payment_info_details[i]['PaymentGatewayStatus'] + ' </td>' +
                                '<td>' + res.result.transaction_payment_info_details[i]['PaymentGatewayStatusDescription'] + ' </td>' +

                                '<td>' + res.result.transaction_payment_info_details[i]['PaymentMode'] + ' </td>' +
                                '<td>' + res.result.transaction_payment_info_details[i]['PgTransId'] + ' </td>' +
                                '<td>' + res.result.transaction_payment_info_details[i]['Remarks'] + ' </td>' +
                                '<td>' + invoice_no + ' </td>' +
                                '<td>' + settle + ' </td>' +

                                '</tr>'
                            )
                        }


                        $('#transaction_payment_info_block').show();
                    }


                } else {

                    UIkit.notification({
                        message: 'Error',
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                    $('#user_table_body').html('');
                    $('#transaction_info_table_body').html('');
                    $('#transaction_payment_info_table_body').html('');


                    $('#user_table_block').hide();
                    $('#transaction_info_block').hide();
                    $('#transaction_payment_info_block').hide();


                }
            }, error: function (res) {

                UIkit.notification({
                    message: 'Nothing to display',
                    status: 'danger',
                    pos: 'bottom-center',
                    timeout: 1000
                });

                $('#user_table_body').html('');
                $('#transaction_info_table_body').html('');
                $('#transaction_payment_info_table_body').html('');


                $('#user_table_block').hide();
                $('#transaction_info_block').hide();
                $('#transaction_payment_info_block').hide();
            }
        });


    }

    function settle(id) {
        UIkit.modal.confirm('Proceed to settle with table entry id ' + id).then(function () {
            jQuery.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>" + "Admin_Controller/settle_order",
                dataType: 'json',
                data: {

                    id: id
                },
                xhr: function () {
                    var xhr = new window.XMLHttpRequest();
                    //Download progress
                    xhr.addEventListener("progress", function (evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = evt.loaded / evt.total;
                            //progressElem.value+=Math.round(percentComplete * 100);
                        }
                    }, false);
                    return xhr;
                },
                beforeSend: function () {
                    $('#progressElem').show();

                },
                complete: function () {
                    $('#progressElem').hide();
                },
                success: function (res) {

                    if (res.status == 'success') {
                        UIkit.notification({
                            message: 'Successfully settled the order',
                            status: 'success',
                            pos: 'bottom-center',
                            timeout: 1000
                        });
                    } else {
                        UIkit.notification({
                            message: 'Failed to settle the order',
                            status: 'danger',
                            pos: 'bottom-center',
                            timeout: 1000
                        });
                    }
                },
                error: function (res) {

                }
            });
        });
    }


    function unsettled_orders(customer_id) {

        jQuery.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>" + "Admin_Controller/show_unsettled_orders",
            dataType: 'json',
            data: {

                customer_id: customer_id
            },
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                //Download progress
                xhr.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                        //progressElem.value+=Math.round(percentComplete * 100);
                    }
                }, false);
                return xhr;
            },
            beforeSend: function () {
                $('#progressElem').show();

            },
            complete: function () {
                $('#progressElem').hide();
            },
            success: function (res) {

                if (res.status = 'success') {
                    var content_body = '';
                    $('#unsettled_orders_modal_body').html();
                    if (res.unsettled_orders) {
                        for (var i = 0; i < res.unsettled_orders.length; i++) {

                            content_body = content_body + '<tr>' +
                            '<td>' + res.unsettled_orders[i]['UNSETTLEDORDERNUMBER'] + '</td>' +
                            '<td>' + res.unsettled_orders[i]['DCNO'] + '</td>' +
                            '<td>' + res.unsettled_orders[i]['PAYABLEAMOUNT'] + '</td>' +
                            '<td>' + res.unsettled_orders[i]['ORDERDATE'] + '</td>' +
                            '<td>' + res.unsettled_orders[i]['TRANSACTIONDATE'] + '</td>' +
                            '<td>' + res.unsettled_orders[i]['GARMENTSCOUNT'] + '</td>' +
                            '</tr>';
                        }
                    } else {
                        content_body = content_body + 'No unsettled orders are available!';
                    }

                    $('#unsettled_orders_modal_body').html(content_body);


                    UIkit.modal('#unsettled_orders_modal').show();


                } else {
                    UIkit.notification({
                        message: 'Nothing to display',
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                }
            },
            error: function () {

            }
        });
    }

    function update_dcn(id) {
        UIkit.modal.prompt('Enter the DCN', '').then(function (dcn) {
            jQuery.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>" + "Admin_Controller/update_dcn",
                dataType: 'json',
                data: {

                    id: id,
                    dcn: dcn
                },
                xhr: function () {
                    var xhr = new window.XMLHttpRequest();
                    //Download progress
                    xhr.addEventListener("progress", function (evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = evt.loaded / evt.total;
                            //progressElem.value+=Math.round(percentComplete * 100);
                        }
                    }, false);
                    return xhr;
                },
                beforeSend: function () {
                    $('#progressElem').show();

                },
                complete: function () {
                    $('#progressElem').hide();
                },
                success: function (res) {

                    if (res.status == 'success') {
                        UIkit.notification({
                            message: 'Successfully updated the DCN',
                            status: 'success',
                            pos: 'bottom-center',
                            timeout: 1000
                        });
                    } else {
                        UIkit.notification({
                            message: 'Failed to update the DCN',
                            status: 'danger',
                            pos: 'bottom-center',
                            timeout: 1000
                        });
                    }

                }, error: function (res) {

                }

            });
        });
    }

    function new_payment_info_entry() {
        $('#add_payment_info_entry_block').hide();
        $('#transaction_payment_info_table_body').append('<tr>' +

            '<td> <input class="uk-input" disabled placeholder="Auto generated ID"> </td>' +
            '<td> <input class="uk-input" placeholder="Current Date" disabled></td>' +
            '<td><input class="uk-input" placeholder="Transaction ID" id="new_transaction_id"></td>' +
            '<td><input class="uk-input" placeholder="Payment ID" id="new_payment_id"></td>' +
            '<td><input class="uk-input" placeholder="Payment Amount" id="new_payment_amount"></td>' +
            '<td><input class="uk-input" placeholder="Payment Gateway status" id="new_gateway_status"> </td>' +
            '<td><input class="uk-input" placeholder="Payment Gateway status description" id="new_gateway_description"></td>' +

            '<td><input class="uk-input" placeholder="Payment Mode" id="new_payment_mode"></td>' +
            '<td><input class="uk-input" placeholder="PgTransId" id="new_pg_trans_id"> </td>' +
            '<td><input class="uk-input" placeholder="Remarks" id="new_remarks"></td>' +
            '<td><a type="button" onclick="save_new_payment_info_entry();return false;" class="uk-button uk-button-default">Save</a> </td>' +
            '</tr>'
        )
        $('#transaction_payment_info_block').show();
    }

    function save_new_payment_info_entry() {
        var transaction_id = $('#new_transaction_id').val();
        var payment_id = $('#new_payment_id').val();
        var amount = $('#new_payment_amount').val();
        var gateway_status = $('#new_gateway_status').val();
        var gateway_description = $('#new_gateway_description').val();
        var payment_mode = $('#new_payment_mode').val();
        var pg_trans_id = $('#new_pg_trans_id').val();
        var remarks = $('#new_remarks').val();


        jQuery.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>" + "Admin_Controller/save_transaction_payment_info",
            dataType: 'json',
            data: {
                transaction_id: transaction_id,
                payment_id: payment_id,
                amount: amount,
                gateway_status: gateway_status,
                gateway_description: gateway_description,
                payment_mode: payment_mode,
                pg_trans_id: pg_trans_id,
                remarks: remarks
            },
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                //Download progress
                xhr.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                        //progressElem.value+=Math.round(percentComplete * 100);
                    }
                }, false);
                return xhr;
            },
            beforeSend: function () {
                $('#progressElem').show();

            },
            complete: function () {
                $('#progressElem').hide();
            },
            success: function (res) {

                if (res.status == 'success') {
                    UIkit.notification({
                        message: 'Successfully saved an entry',
                        status: 'success',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                } else {
                    UIkit.notification({
                        message: 'Failed to save an entry!',
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });
                }
            },
            error: function (res) {
                UIkit.notification({
                    message: 'Failed to save an entry!',
                    status: 'danger',
                    pos: 'bottom-center',
                    timeout: 1000
                });
            }
        });
        return false;
    }
</script>

<style>
    #user_table_block, #transaction_info_block, #transaction_payment_info_block {
        margin-top: 20px;
    }
</style>


<div class="uk-width-1-1@s uk-width-4-5@m uk-margin-auto-left content_wrapper">

    <div>
        <div class="uk-card uk-card-default uk-card-hover uk-card-body">

            <h3 class="uk-card-title uk-heading-primary uk-text-center">Payment Gateway Center</h3>


            <hr class="uk-divider-icon">
            <form class="uk-form-stacked">


                <div class="uk-margin">
                    <label class="uk-form-label" for="search_with">Search with</label>

                    <div class="uk-form-controls">
                        <select class="uk-select" id="search_with">
                            <option value="egrn">EGRN</option>
                            <option value="payment_id">Payment ID</option>

                        </select>
                    </div>
                </div>


                <div class="uk-margin">
                    <label class="uk-form-label" for="search_text">Search</label>

                    <div class="uk-form-controls">
                        <input class="uk-input" id="search_text" type="text"
                               placeholder="Search something...">
                    </div>
                </div>

                <div class="uk-margin uk-flex uk-flex-center">
                    <button class="uk-button uk-button-primary " id="search_button">Search</button>
                    <div uk-spinner id="loading"></div>
                </div>


            </form>
        </div>
    </div>

    <div id="user_table_block">
        <h4 class="uk-text-center">Customer Details</h4>
        <table id="user_table" class="uk-table uk-table-hover uk-table-divider">
            <thead>
            <tr>
                <th>Customer Code</th>
                <th>Customer Name</th>
                <th>Customer Mobile Number</th>
                <th>Customer Email</th>
                <th>Unsettled orders</th>
            </tr>
            </thead>
            <tbody id="user_table_body">


            </tbody>
        </table>
    </div>

    <div id="transaction_info_block">
        <h4 class="uk-text-center uk-margin-top">Entries in Transaction Info table</h4>
        <table id="transaction_info_table" class="uk-table uk-table-hover uk-table-divider">
            <thead>
            <tr>
                <th>ID</th>
                <th>Transaction Date</th>
                <th>Transaction ID</th>
                <th>Payment ID</th>
                <th>EGRN</th>
                <th>DCN</th>
                <th>Amount</th>
                <th>Source</th>
            </tr>
            </thead>
            <tbody id="transaction_info_table_body">

            </tbody>
        </table>
    </div>


    <div id="transaction_payment_info_block">
        <h4 class="uk-text-center uk-margin-top">Entries in Transaction Payment Info table</h4>
        <table id="transaction_payment_info_table" class="uk-table uk-table-hover uk-table-divider">
            <thead>
            <tr>
                <th>ID</th>
                <th>Created Date</th>
                <th>Transaction ID</th>
                <th>Payment ID</th>
                <th>Amount</th>
                <th>Payment Gateway status</th>
                <th>Payment Gateway description</th>
                <th>Payment Mode</th>
                <th>PgTransId</th>
                <th>Remarks</th>
                <th>Invoice Number</th>
                <th>Settlement Procedure</th>
            </tr>
            </thead>
            <tbody id="transaction_payment_info_table_body">

            </tbody>
        </table>
    </div>

    <div id="unsettled_orders_modal" class="uk-modal-container" uk-modal>
        <div class="uk-modal-dialog uk-modal-body">
            <table class="uk-table uk-table-striped">
                <thead>
                <tr>
                    <th>Unsettled Order Number(EGRN/DCN)</th>
                    <th>DCN</th>
                    <th>Amount</th>
                    <th>Order Date</th>
                    <th>Transaction Date</th>
                    <th>Garments Count</th>

                </tr>
                </thead>
                <tbody id="unsettled_orders_modal_body">

                </tbody>
            </table>
        </div>
    </div>

</div>

