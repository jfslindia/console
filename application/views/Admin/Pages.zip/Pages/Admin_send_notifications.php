<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<script type="text/javascript">

    $(document).ready(function () {
        $('#send_notification_block').hide();
        $('#location_limit_block').hide();

        $('#emails').show();
        $('#mobile_numbers').hide();
        $('#gcmids').hide();

        $('#send_to').change(function(){

            if ($('#send_to').val()=='all'){

                $('#list_via_block').hide();
                $('#receivers_list_block').hide();
                $('#location_limit_block').show();

            }else if($('#send_to').val()=='selected'){
                $('#list_via_block').show();
                $('#location_limit_block').hide();
                $('#receivers_list_block').show();
                $('#list_via').val == 'email';
                $("#list_via option[value='email']").attr('selected','selected');
            }

        });

        $('#list_via').change(function () {
            if ($('#list_via').val() == 'email') {
                $('#get_gcmid_block').show();
                $('#result_block').hide();
                $('#send_notification_block').hide();
                $('#emails').show();
                $('#mobile_numbers').hide();
                $('#gcmids').hide();
            } else if ($('#list_via').val() == 'mobile_number') {
                $('#get_gcmid_block').show();
                $('#result_block').hide();
                $('#send_notification_block').hide();
                $('#mobile_numbers').show();
                $('#emails').hide();
                $('#gcmids').hide();
            } else if ($('#list_via').val() == 'gcmid') {
                $('#get_gcmid_block').hide();
                $('#result_block').hide();
                $('#send_notification_block').show();
                $('#gcmids').show();
                $('#emails').hide();
                $('#mobile_numbers').hide();
            }
        });

        $('#get_gcmid').click(function () {

            console.log($('#send_to').val())

            if($('#send_to').val()=='selected') {

                var brand = $('#brand').val();
                var device = $('#device').val();
                var via = $('#list_via').val();
                var via_element = '#' + via + 's';
                var inputs = $(via_element).val();
                var raw_inputs = inputs.replace(/ /g, '')

                var list = raw_inputs.split(',');

                jQuery.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>" + "admin_controller/get_gcmids",
                    dataType: 'json',
                    data: {
                        via: via,
                        device: device,
                        list: list,
                        brand: brand

                    },
                    xhr: function () {
                        var xhr = new window.XMLHttpRequest();
                        //Download progress
                        xhr.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total;
                                //progressElem.value+=Math.round(percentComplete * 100);
                            }
                        }, false);
                        return xhr;
                    },
                    beforeSend: function () {
                        //$('#loading').show();
                        $.blockUI({

                            message: '<h1>Please wait...</h1>'

                        });

                    },
                    complete: function () {
                        $.unblockUI();

                    },
                    success: function (res) {

                        //console.log(res)

                        if (res.status == 'success') {

                            var output = '';
                            for (var i = 0; i < res.gcmids.length; i++) {
                                if (i != res.gcmids.length - 1)
                                    output = output + res.gcmids[i].gcmid + ',';
                                else
                                    output = output + res.gcmids[i].gcmid;
                            }
                            $('#result').val(output);


                            $('#result_block').show();
                            $('#send_notification_block').show();
                        }
                        else if (res.status == 'failed') {
                            $('#result_block').hide();
                            $('#send_notification_block').hide();
                            $('#result').val('');
                            UIkit.notification({
                                message: 'No GCMIDs available',
                                status: 'danger',
                                pos: 'bottom-center',
                                timeout: 1000
                            });
                        }


                    }, error: function (res) {

                        //console.log(res);
                    }

                });

            }else{

                var brand = $('#brand').val();
                var device = $('#device').val();
                var location =$('#location').val();
                var start=$('#start').val();
                var limit=$('#limit').val();
                jQuery.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>" + "admin_controller/get_all_gcmids",
                    dataType: 'json',
                    data: {
                      brand:brand,
                        device:device,
                        location:location,
                        start:start,
                        limit:limit
                    },
                    xhr: function () {
                        var xhr = new window.XMLHttpRequest();
                        //Download progress
                        xhr.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total;
                                //progressElem.value+=Math.round(percentComplete * 100);
                            }
                        }, false);
                        return xhr;
                    },
                    beforeSend: function () {
                        //$('#loading').show();
                        $.blockUI({

                            message: '<h1>Please wait...</h1>'

                        });

                    },
                    complete: function () {
                        $.unblockUI();

                    },
                    success: function (res) {

                        console.log(res)

                        if (res.status == 'success') {

                            var output = '';
                            for (var i = 0; i < res.gcmids.length; i++) {
                                if (i != res.gcmids.length - 1)
                                    output = output + res.gcmids[i].gcmid + ',';
                                else
                                    output = output + res.gcmids[i].gcmid;
                            }
                            $('#result').val(output);


                            $('#result_block').show();
                            $('#send_notification_block').show();
                        }
                        else if (res.status == 'failed') {
                            $('#result_block').hide();
                            $('#send_notification_block').hide();
                            $('#result').val('');
                            UIkit.notification({
                                message: 'No GCMIDs available',
                                status: 'danger',
                                pos: 'bottom-center',
                                timeout: 1000
                            });
                        }


                    }, error: function (res) {

                        //console.log(res);
                    }

                });

            }

        });

        $('#send_notification').click(function () {

            var device  = $('#device').val();
            var via = $('#list_via').val();
            if (via == 'gcmid')
                var to_sent = $('#gcmids').val().split(',');
            else
                var to_sent = $('#result').val().split(',');


            var title = $('#title').val();
            var image_url = $('#image_url').val();
            var brand = $('#brand').val();
            var message = $('#message').val();

            if (!title) {
                UIkit.notification({
                    message: 'No title is provided',
                    status: 'danger',
                    pos: 'bottom-center',
                    timeout: 1000
                });

                return true;
            }

            if (!message) {
                UIkit.notification({
                    message: 'No message content is provided',
                    status: 'danger',
                    pos: 'bottom-center',
                    timeout: 1000
                });

                return true;
            }
            //console.log(brand);
            jQuery.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>" + "admin_controller/send_gcmids",
                dataType: 'json',
                data: {
                    device:device,
                    to_sent: to_sent,
                    title: title,
                    image_url: image_url,
                    brand: brand,
                    message: message
                },
                xhr: function () {
                    var xhr = new window.XMLHttpRequest();
                    //Download progress
                    xhr.addEventListener("progress", function (evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = evt.loaded / evt.total;
                            //progressElem.value+=Math.round(percentComplete * 100);
                        }
                    }, false);
                    return xhr;
                },
                beforeSend: function () {
                    //$('#loading').show();
                    $.blockUI({

                        message: '<h1>Please wait...</h1>'

                    });

                },
                complete: function () {
                    $.unblockUI();

                },
                success: function (res) {
                    //console.log(res);
                    //console.log(res);
                    if (res.status == 'success') {

                        UIkit.notification({
                            message: 'Successfully sent',
                            status: 'success',
                            pos: 'bottom-center',
                            timeout: 1000
                        });
                    }
                },

                error: function (res) {
                    //console.log(res);
                }
            });

        });
        /*$('#send_notification').click(function(){
    //console.log('asdasd');
});*/

    });


</script>

<div id="page-1-container" class="uk-width-1-1@s uk-width-4-5@m uk-margin-auto-left content_wrapper">

    <div class="uk-card uk-align-center uk-card-default uk-card-hover uk-card-body">

        <!--uk-width-1-2@l uk-width-1-2@m uk-width-1-2@s-->

        <h3 class="uk-heading-divider uk-text-center">Send Notification</h3>
        <h5 class="uk-text-center">Send Push Notification</h5>
        <div class="uk-grid" id="grid">

            <form class="uk-form-horizontal uk-width-expand">
                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Brand</label>

                    <div class="uk-form-controls">
                        <select class="uk-select" id="brand">

                            <option value="Fabricspa">Fabricspa</option>
                            <option value="Click2Wash">Click2Wash</option>
                        </select>
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Device</label>

                    <div class="uk-form-controls">
                        <select class="uk-select" id="device">
                            <option value="android">Android</option>
                            <option value="ios">iOS</option>
                        </select>
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Send to</label>

                    <div class="uk-form-controls">
                        <select class="uk-select" id="send_to">
                            <option value="selected">Selected Users</option>
                            <option value="all">All</option>
                        </select>
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Title</label>

                    <div class="uk-form-controls">
                        <input type="text" id="title" class="uk-input" placeholder="Enter the notification message title">
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Image</label>

                    <div class="uk-form-controls">
                        <input type="text" id="image_url" class="uk-input" placeholder="Enter the image URL">
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Message</label>

                    <div class="uk-form-controls">
                        <input type="text" id="message" class="uk-textarea" placeholder="Enter the message content">
                    </div>
                </div>

                <div id="list_via_block" class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Get receivers list via</label>

                    <div class="uk-form-controls">
                        <select class="uk-select" id="list_via">
                            <option value="">Select</option>
                            <option value="email" selected>Email</option>
                            <option value="mobile_number">Mobile Number</option>
                            <option value="gcmid">GCMID</option>
                        </select>
                    </div>
                </div>

                <div id="location_limit_block">
                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Location</label>

                    <div class="uk-form-controls">
                        <select id="location" class="uk-select">
                            <option value="">No specific location</option>
                            <option value="Bangalore">Bangalore</option>
                            <option value="Chennai">Chennai</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Hubli">Hubli</option>
                            <option value="Mangalore">Mangalore</option>
                            <option value="Mumbai">Mumbai</option>
                            <option value="Mysore">Mysore</option>
                            <option value="Pune">Pune</option>

                        </select>
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Start & Limit</label>

                    <div class="uk-form-controls">
                        <div class="uk-grid uk-margin-auto uk-child-width-1-2@m">
                        <input type="text" id="start" class="uk-input" placeholder="Enter the start value">
                            <input type="text" id="limit" class="uk-input" placeholder="Enter a limit">
                        </div>
                    </div>
                </div>
                </div>


                <div id="receivers_list_block">
                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Receivers List</label>

                    <div class="uk-form-controls">

                        <textarea class="uk-textarea" id="emails" rows="5"></textarea>
                    </div>

                    <div class="uk-form-controls">

                        <textarea class="uk-textarea" id="mobile_numbers" rows="5"></textarea>
                    </div>

                    <div class="uk-form-controls">
                        <textarea class="uk-textarea" id="gcmids" rows="5"></textarea>
                    </div>
                </div>
                </div>

                <div class="uk-margin" id="get_gcmid_block">
                    <button id="get_gcmid" type="button"
                            class="uk-button uk-button-primary uk-width-1-1">
                        Get GCMID
                    </button>
                </div>

                <div class="uk-margin" id="result_block" style="display: none;">
                    <label class="uk-form-label" for="form-horizontal-text">Result</label>

                    <div class="uk-form-controls">
                        <textarea class="uk-textarea" id="result" rows="10" readonly></textarea>
                    </div>
                </div>

                <div class="uk-margin" id="send_notification_block">
                    <button id="send_notification" type="button"
                            class="uk-button uk-button-primary uk-width-1-1">
                        SEND
                    </button>
                </div>


            </form>
        </div>
    </div>
</div>