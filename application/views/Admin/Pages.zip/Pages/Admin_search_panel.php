<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<script>
    $(document).ready(function () {

        $('#loading').hide();
        $('#user_table_block').hide();
        $('#orders_table_block').hide();


        $('#search_text').keydown(function (event) {

            if (event.keyCode == 13) {
                $('#search_button').hide();
                event.preventDefault();
                search();
            }

        });


        $('#search_button').click(function (event) {
            $('#search_button').hide();
            event.preventDefault();
            search();
        });

    });


    function search() {

        var search_with = $('#search_with').val();
        var search_text = $('#search_text').val();


        jQuery.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>" + "Admin_Controller/search_panel",
            dataType: 'json',
            data: {
                search_with: search_with,
                search_text: search_text
            },
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                //Download progress
                xhr.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                        //progressElem.value+=Math.round(percentComplete * 100);
                    }
                }, false);
                return xhr;
            },
            beforeSend: function () {
                $('#loading').show();


            },
            complete: function () {
                $("#loading").hide();
                $('#search_button').show();

            },
            success: function (res) {
                //console.log(res);

                if (res.status == "failed") {
                    // Show Entered Value

                    UIkit.notification({
                        message: 'No such results',
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });
                    $('#user_table_body').html('');
                    $('#orders_table_body').html('');


                    $('#user_table_block').hide();
                    $('#orders_table_block').hide();
                }
                else if (res.status == "error") {

                    UIkit.notification({
                        message: res.message,
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                    $('#user_table_body').html('');
                    $('#orders_table_body').html('');


                    $('#user_table_block').hide();
                    $('#orders_table_block').hide();

                }

                else if (res.status == "success") {

                    console.log(res.result.order_details[0].length)


                    $('#user_table_body').html('');
                    $('#orders_table_body').html('');

                    console.log(res)
                    UIkit.notification({
                        message: 'Succesfully retreived results',
                        status: 'success',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                    if (search_with != 'name') {

                        for (var i = 0; i < res.result.user_details.length; i++) {

                            $('#user_table_body').append('<tr>' +

                                '<td>' + res.result.user_details[i]['customer_id'] + ' </td>' +
                                '<td>' + res.result.user_details[i]['name'] + ' </td>' +
                                '<td>' + res.result.user_details[i]['mobile_number'] + ' </td>' +
                                '<td>' + res.result.user_details[i]['email'] + ' </td>' +
                                '</tr>'
                            )
                        }

                        $('#user_table_block').show();

                        if (res.result.order_details.length > 0) {


                            for (var i = 0; i < res.result.order_details.length; i++) {

                                $('#orders_table_body').append('<tr>' +

                                    '<td>' + res.result.order_details[i]['date'] + ' </td>' +
                                    '<td>' + res.result.order_details[i]['pick_up_date'] + ' </td>' +
                                    '<td>' + res.result.order_details[i]['customer_id'] + ' </td>' +
                                    '<td>' + res.result.order_details[i]['bookingID'] + ' </td>' +
                                    '<td>' + res.result.order_details[i]['reference_number'] + ' </td>' +
                                    '<td>' + res.result.order_details[i]['order_status'] + ' </td>' +
                                    '</tr>'
                                )
                            }

                            $('#orders_table_block').show();
                        } else {
                            $('#orders_table_body').html('')
                            $('#orders_table_block').hide();
                        }

                    } else {

                        for (var i = 0; i < res.result.user_details.length; i++) {

                            $('#user_table_body').append('<tr>' +

                                '<td>' + res.result.user_details[i]['customer_id'] + ' </td>' +
                                '<td>' + res.result.user_details[i]['name'] + ' </td>' +
                                '<td>' + res.result.user_details[i]['mobile_number'] + ' </td>' +
                                '<td>' + res.result.user_details[i]['email'] + ' </td>' +
                                '</tr>'
                            )

                            $('#user_table_block').show();

                            for (var j = 0; j < res.result.order_details[i].length; j++) {


                                $('#orders_table_body').append('<tr>' +

                                    '<td>' + res.result.order_details[i][j]['date'] + ' </td>' +
                                    '<td>' + res.result.order_details[i][j]['pick_up_date'] + ' </td>' +
                                    '<td>' + res.result.order_details[i][j]['customer_id'] + ' </td>' +
                                    '<td>' + res.result.order_details[i][j]['bookingID'] + ' </td>' +
                                    '<td>' + res.result.order_details[i][j]['reference_number'] + ' </td>' +
                                    '<td>' + res.result.order_details[i][j]['order_status'] + ' </td>' +
                                    '</tr>'
                                )
                            }
                            $('#orders_table_block').show();

                        }
                    }


                } else {

                    UIkit.notification({
                        message: 'Error',
                        status: 'danger',
                        pos: 'bottom-center',
                        timeout: 1000
                    });

                    $('#user_table_body').html('');
                    $('#orders_table_body').html('');


                    $('#user_table_block').hide();
                    $('#orders_table_block').hide();


                }
            }, error: function (res) {

                UIkit.notification({
                    message: 'Nothing to display',
                    status: 'danger',
                    pos: 'bottom-center',
                    timeout: 1000
                });

                $('#user_table_body').html('');
                $('#orders_table_body').html('');


                $('#user_table_block').hide();
                $('#orders_table_block').hide();
            }
        });


    }
</script>

<style>
    #user_table_block, #orders_table_block {
        margin-top: 20px;
    }
</style>


    <div class="uk-width-1-1@s uk-width-4-5@m uk-margin-auto-left content_wrapper">

        <div>
            <div class="uk-card uk-card-default uk-card-hover uk-card-body">

                <h3 class="uk-card-title uk-heading-primary uk-text-center">Search Panel</h3>


                <hr class="uk-divider-icon">
                <form class="uk-form-stacked">


                    <div class="uk-margin">
                        <label class="uk-form-label" for="search_with" >Search with</label>
                        <div class="uk-form-controls">
                            <select class="uk-select" id="search_with">
                                <option value="name">Name</option>
                                <option value="mobile_number">Mobile Number</option>
                                <option value="customer_id">Customer ID</option>
                                <option value="email">Email</option>
                                <option value="order_id">Mobile Order ID</option>
                                <option value="booking_id">Booking ID</option>
                            </select>
                        </div>
                    </div>


                    <div class="uk-margin">
                        <label class="uk-form-label" for="search_text">Search Text</label>
                        <div class="uk-form-controls">
                            <input class="uk-input" id="search_text" type="text"
                                   placeholder="Search something here..." >
                        </div>
                    </div>

                    <div class="uk-margin uk-flex uk-flex-center">
                        <button class="uk-button uk-button-primary " id="search_button">Search</button>
                        <div uk-spinner id="loading"></div>
                    </div>


                </form>
            </div>
        </div>

        <div id ="user_table_block">
            <h4 class="uk-text-center">Customer Details</h4>
            <table id ="user_table" class="uk-table uk-table-hover uk-table-divider">
                <thead>
                <tr>
                    <th>Customer Code</th>
                    <th>Customer Name</th>
                    <th>Customer Mobile Number</th>
                    <th>Customer Email</th>
                </tr>
                </thead>
                <tbody id="user_table_body">


                </tbody>
            </table>
        </div>

        <div id ="orders_table_block">
            <h4 class="uk-text-center uk-margin-top">Orders Details</h4>
            <table id ="orders_table" class="uk-table uk-table-hover uk-table-divider">
                <thead>
                <tr>
                    <th>Pickup Created Date</th>
                    <th>Pickup Date</th>
                    <th>Customer Code</th>
                    <th>Booking ID</th>
                    <th>Reference Number</th>
                    <th>Order Status</th>
                </tr>
                </thead>
                <tbody id="orders_table_body">

                </tbody>
            </table>
        </div>

    </div>

