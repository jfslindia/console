<?php
/**
 * Created by PhpStorm.
 * User: targetman
 * Date: 4/5/2017
 * Time: 2:10 PM
 */

?>

<html lang="en-US">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>

    <title>JFSL ADMIN</title>


    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom/admin.css"/>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/core/uikit.min.css"/>

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/core/uikit-icons.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/core/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/core/uikit.min.js"></script>


    <!--JQUERY DATEPICKER -- THEME ROLLER-->

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/core/jquery-ui/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/js/core/jquery-ui/jquery-ui.min.css"/>


</head>

<body>

