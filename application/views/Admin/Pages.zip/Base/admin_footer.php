<?php
/**
 * Created by PhpStorm.
 * User: targetman
 * Date: 4/5/2017
 * Time: 2:23 PM
 */
?>


<script type="text/javascript">
	$('.content_wrapper').addClass('uk-animation-scale-up uk-transform-origin-bottom-center');

	$(document).ready(function(){
	    $('#to-top').hide();
    });

</script>

</div>
</body>
</html>